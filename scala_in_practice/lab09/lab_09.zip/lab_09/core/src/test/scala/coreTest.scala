package core

import org.scalatest.funsuite.AnyFunSuite
import org.scalatest.matchers.should.Matchers

class CardSuite extends AnyFunSuite {
  test("Ace is neither face or numerical value") {
    val exampleAce = Card(Hearts, Ace)
    assert(!(exampleAce.isFace() && exampleAce.isNumerical()))
  }
  test("isValue should work on face values") {
    val exampleJack = Card(Spades, Jack)
    assert(exampleJack.isValue(Jack))
  }
}

class DeckSuite extends AnyFunSuite with Matchers {
  val deck = Deck()
  val cards = deck.cards
  test("Push on deck creates a deck with one more card") {
    assert(deck.push(Card(Hearts, Jack)).cards.length == 1 + cards.length)
  }
  test("Pull on empty deck throws EmptyDeckException") {
    val emptyDeck = new Deck(List())
    assertThrows[EmptyDeckException](emptyDeck.pull())
  }
  test("Deck created with apply() should be standard") {
    assert(Deck().isStandard)
  }
  test("Standard deck should have no duplicates") {
    cards.filter(deck.duplicatesOfCard(_) > 0) shouldBe empty
  }
  test("Standard deck has 12 faces") {
    deck.amountWithFace should equal(12)
  }
  test("Standard deck has 36 faces") {
    deck.amountWithNumerical should equal(36)
  }
  test("Standard deck should have 4 cards of each face") {
    for {
      face <- List(Jack, Queen, King)
    } deck.amountOfFace(face) should equal(4)
  }
  test("Standard deck should have 13 cards of each color") {
    for {
      color <- List(Hearts, Diamonds, Clubs, Spades)
    } deck.amountOfColor(color) should equal(13)
  }
}

