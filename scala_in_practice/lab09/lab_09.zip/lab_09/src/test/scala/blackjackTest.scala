package blackjack

import org.scalatest.funsuite.AnyFunSuite
import org.scalatest.matchers.should.Matchers
import core._

class BlackjackSuite extends AnyFunSuite {
  val blackjack = Blackjack(3)
  test("all21 on empty deck should return empty list") {
    val emptyBlackjack = new Blackjack(new Deck(List()))
    assert(emptyBlackjack.all21 == List())
  }

}